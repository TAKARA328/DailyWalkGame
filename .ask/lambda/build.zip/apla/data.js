module.exports = apla_data;

function apla_data() {
    return {
        myData: {
            ssml: "ssml",
            audio: "audio",
            volume: "40%"
        }
    }
}